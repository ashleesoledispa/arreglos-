
// Función para verificar si el estudiante aplica para la beca
int aplicaParaBeca(int calificaciones[], int numCalificaciones) {
    // Calcular el promedio utilizando la función ya existente
    float promedio = calcularPromedio(calificaciones, numCalificaciones);

    // Verificar si el promedio es mayor a 8
    if (promedio > 8.0) {
        return 1;  // True
    } else {
        return 0;  // False
    }
}

int main() {
    // Ejemplo de uso
    int calificacionesEstudiante[] = {9, 8, 7, 9, 10};
    int numCalificaciones = sizeof(calificacionesEstudiante) / sizeof(calificacionesEstudiante[0]);

    if (aplicaParaBeca(calificacionesEstudiante, numCalificaciones)) {
        printf("El estudiante aplica para la beca.\n");
    } else {
        printf("El estudiante no cumple con los requisitos para la beca.\n");
    }

    return 0;
}
