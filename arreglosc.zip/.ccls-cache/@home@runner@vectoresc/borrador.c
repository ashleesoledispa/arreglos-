def es_apto_para_beca(promedio):
    """
    Determina si un estudiante es apto para recibir una beca.

    Parameters:
    - promedio (float): El promedio del estudiante.

    Returns:
    - bool: True si el estudiante es apto, False en caso contrario.
    """
    return promedio > 8.0

# Ejemplo de uso:
promedio_estudiante = float(input("Ingresa el promedio del estudiante: "))

if es_apto_para_beca(promedio_estudiante):
    print("El estudiante es apto para recibir la beca.")
else:
    print("El estudiante no es apto para recibir la beca.")
