#include "funciones.h"
#include "menu.h"
#include <stdio.h>

int main(void) {
  int opc;
  int calificaciones[3];
  float lluvia[12];

  do {
    opc = menuPrincipal();
    switch (opc) {
    case 1:
      ingresarCalificaciones(calificaciones, 3);
      mostrarCalificaciones(calificaciones, 3);
      break;
    case 2:
      ingresarLluviaAnual(lluvia, 12);
      mostrarLluviaAnual(lluvia, 12);
      break;
    case 3:
      promedioCalificaciones(calificaciones, 3);
      printf("El promedio de las calificaciones es: %.2f\n",
             promedioCalificaciones(calificaciones, 3));
      break;
    case 4:
      promedioLluviaAnual(lluvia, 12);
      printf("El promedio de lluvias anuales es: %.2f\n",
             promedioLluviaAnual(lluvia, 12));
      break;
    case 5:
      candidatoBeca(calificaciones, 3);
      break;
    case 6:
      printf("Gracias por usar el programa \n");
      break;
    default:
      printf("Esta opcion no es valida \n");
      break;
    }
  } while (opc != 6);
}