#include "menu.h"
#include "lecturas.h"
#include <stdio.h>
int menuPrincipal() {
  printf("Elija una opcion \n");
  printf("1.- Ingresar calificaciones\n");
  printf("2.- Ingresar promedio de lluvia anual\n");
  printf("3.- Promedio de calificaciones \n");
  printf("4.- Promedio de lluvia anual\n");
  printf("5.- Estudiantes candidatos a beca\n");
  printf("6.- Salir \n");
  return leerEnteroEntre("Opcion", 1, 5);
}