void ingresarCalificaciones(int[], int);
void mostrarCalificaciones(const int[], int);
void ingresarLluviaAnual(float[], float);
void mostrarLluviaAnual(const float[], float);
float promedioCalificaciones(int[], int);
float promedioLluviaAnual(float[], float);
void candidatoBeca(int[], int);
