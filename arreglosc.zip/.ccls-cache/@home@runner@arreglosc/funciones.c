#include "funciones.h"
#include "lecturas.h"
#include <stdio.h>

void ingresarCalificaciones(int notas[], int tamanio) {
  for (int i = 0; i < tamanio; i++) {
    notas[i] = leerEnteroEntre("Ingrese una calficacion entre 1 y 10: ", 1, 10);
    // printf("Ingrese una nota entre 1 y 10: ");
    // scanf("%d", &notas[i]);
  }
}
void mostrarCalificaciones(const int notas[], int tamanio) {
  for (int i = 0; i < tamanio; i++) {
    printf("Calificacion %d: %d\n", (i + 1), notas[i]);
  }
}
void ingresarLluviaAnual(float datos[], float tamanio) {
  for (int i = 0; i < tamanio; i++) {
    datos[i] = leerFlotantePositivo("Ingrese la lluvia del mes: ");
  }
}

void mostrarLluviaAnual(const float datos[], float tamanio) {
  for (int i = 0; i < tamanio; i++) {
    printf("Lluvia %d: %f\n", (i + 1), datos[i]);
  }
}
float promedioCalificaciones(int notas[], int tamanio) {
  int suma = 0;
  float promedio = 0;

  for (int i = 0; i < tamanio; i++) {
    suma += notas[i];
  }
  promedio = (float)suma / tamanio;
  return promedio;
}

float promedioLluviaAnual(float datos[], float tamanio) {
  float suma = 0;
  float promedio = 0;

  for (int i = 0; i < tamanio; i++) {
    suma += datos[i];
  }
  promedio = suma / tamanio;
  return promedio;
}

void candidatoBeca(int notas[], int tamanio) {
  float promedio = promedioCalificaciones(notas, tamanio);

  if (promedio > 8.0) {
    printf("Si es candidato a beca, promedio mayor a 8 \n");
  } else {
    printf("No es candidato a beca, no cumple los requisitos \n");
  }
}
