#include <stdio.h>

#define MESES 12

void calcularLluviaAnual(const float datos[][MESES], int filas, int columnas) {
  float suma = 0;
  float promedioTotal;

  for (int i = 0; i < filas; i++) {
    float sumaAnual = 0;
    for (int j = 0; j < columnas; j++) {
      sumaAnual += datos[i][j];
    }

    suma += sumaAnual;

    printf("La cantidad de lluvia en el año %d es %.2f\n", i + 1, sumaAnual);
    printf("\n");
  }

  promedioTotal = suma / (filas * columnas);

  printf("El promedio de lluvia en total es %.2f\n", promedioTotal);
}

int main() {
  // Ejemplo de uso
  const float datos[3][MESES] = {{10.5, 20.3, 15.2, 18.5, 12.8, 25.0, 30.5, 22.7, 19.8, 17.3, 12.0, 15.5},
                                {15.0, 18.5, 22.0, 14.3, 16.8, 20.5, 25.2, 19.7, 17.8, 16.3, 13.5, 18.0},
                                {12.2, 21.8, 16.5, 19.0, 14.8, 27.3, 28.0, 20.5, 18.3, 15.5, 11.2, 14.7}};

  calcularLluviaAnual(datos, 3, MESES);

  return 0;
}
